#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#define user_procTaskPrio        0
#define user_procTaskQueueLen    1
#define USE_US_TIMER

#endif
